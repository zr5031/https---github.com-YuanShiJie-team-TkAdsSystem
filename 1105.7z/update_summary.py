from flask import Flask
from flask_sqlalchemy import SQLAlchemy
from sqlalchemy import func
import logging
from apscheduler.schedulers.background import BackgroundScheduler
from datetime import datetime
import requests
import json
import os
from config import DB_CONFIG, TIKTOK_CONFIG, PROXY_CONFIG, APP_CONFIG

# 设置代理
os.environ['http_proxy'] = PROXY_CONFIG['http']
os.environ['https_proxy'] = PROXY_CONFIG['https']

# 设置日志
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = (
    f"mysql+pymysql://{DB_CONFIG['user']}:{DB_CONFIG['password']}"
    f"@{DB_CONFIG['host']}/{DB_CONFIG['database']}"
)
db = SQLAlchemy(app)

class CampaignInfo(db.Model):
    __tablename__ = 'campaign_info'
    id = db.Column(db.Integer, primary_key=True)
    tiktok_campaign_id = db.Column(db.String(32))
    name = db.Column(db.String(255))
    total_spend = db.Column(db.Float(6,2), default=0)
    total_installs = db.Column(db.Integer, default=0)
    total_clicks = db.Column(db.Integer, default=0)
    total_impressions = db.Column(db.Integer, default=0)
    total_purchases = db.Column(db.Integer, default=0)
    start_date = db.Column(db.Date)
    end_date = db.Column(db.Date)
    cpi = db.Column(db.Float(6,2), default=0)
    cpm = db.Column(db.Float(6,2), default=0)
    cpc = db.Column(db.Float(6,2), default=0)
    cpa = db.Column(db.Float(6,2), default=0)
    ctr = db.Column(db.Float(6,2), default=0)
    cvr = db.Column(db.Float(6,2), default=0)
    metrics = db.relationship('CampaignMetrics', backref='campaign', lazy=True)

class CampaignMetrics(db.Model):
    __tablename__ = 'campaign_metrics'
    id = db.Column(db.Integer, primary_key=True)
    campaign_id = db.Column(db.Integer, db.ForeignKey('campaign_info.id'))
    installs = db.Column(db.Integer)
    spend = db.Column(db.Float)
    date = db.Column(db.Date)
    clicks = db.Column(db.Integer)
    impressions = db.Column(db.Integer)
    purchase_count = db.Column(db.Integer)

def calculate_rate(numerator, denominator, multiplier=1):
    """安全地计算比率"""
    try:
        if denominator and denominator != 0:
            return round((numerator / denominator) * multiplier, 4)
        return 0
    except:
        return 0

def disable_campaign(tiktok_campaign_id: str):
    """关停TikTok广告"""
    url = f"{TIKTOK_CONFIG['api_base_url']}/adgroup/status/update/"
    
    payload = json.dumps({
        "advertiser_id": TIKTOK_CONFIG['advertiser_id'],
        "adgroup_ids": [tiktok_campaign_id],
        "operation_status": "DISABLE"
    })
    
    headers = {
        'Access-Token': TIKTOK_CONFIG['access_token'],
        'Content-Type': 'application/json'
    }

    try:
        response = requests.post(url, headers=headers, data=payload)
        response.raise_for_status()
        
        result = response.json()
        if result['code'] == 0 and result['message'] == 'OK':
            logger.info(f"已关停广告: {tiktok_campaign_id}")
            return True
        else:
            logger.error(f"关停广告失败 {tiktok_campaign_id}: {result['message']}")
            return False
            
    except Exception as e:
        logger.error(f"关停广告失败 {tiktok_campaign_id}: {str(e)}")
        return False

def check_and_disable_campaigns(campaigns):
    """检查并关停不达标的广告计划"""
    campaigns_to_disable = []
    
    for campaign in campaigns:
        spend = float(campaign.total_spend or 0)
        installs = int(campaign.total_installs or 0)
        
        should_disable = False
        
        # 检查 spend > 2 且 installs = 0
        if spend > 2 and installs == 0:
            logger.info(f"计划 {campaign.tiktok_campaign_id} - 花费过高无安装 (花费: ${spend}, 安装: {installs})")
            should_disable = True
            
        # 检查 CPI > 2
        if installs > 0:
            cpi = spend / installs
            if cpi > 2:
                logger.info(f"计划 {campaign.tiktok_campaign_id} - CPI过高 (CPI: ${cpi:.2f})")
                should_disable = True

        if should_disable:
            campaigns_to_disable.append(campaign.tiktok_campaign_id)

    if campaigns_to_disable:
        logger.info(f"\n开始关停 {len(campaigns_to_disable)} 个不达标计划...")
        for campaign_id in campaigns_to_disable:
            disable_campaign(campaign_id)
        logger.info("关停操作执行完成!")
    else:
        logger.info("没有需要关停的计划")

def update_summary():
    try:
        with app.app_context():
            # 获取汇总数据
            summary = db.session.query(
                CampaignInfo.id,
                CampaignInfo.tiktok_campaign_id,
                CampaignInfo.name,
                func.sum(CampaignMetrics.spend).label('total_spend'),
                func.sum(CampaignMetrics.installs).label('total_installs'),
                func.sum(CampaignMetrics.clicks).label('total_clicks'),
                func.sum(CampaignMetrics.impressions).label('total_impressions'),
                func.sum(CampaignMetrics.purchase_count).label('total_purchases'),
                func.min(CampaignMetrics.date).label('start_date'),
                func.max(CampaignMetrics.date).label('end_date')
            ).join(
                CampaignMetrics,
                CampaignInfo.id == CampaignMetrics.campaign_id
            ).group_by(
                CampaignInfo.id,
                CampaignInfo.tiktok_campaign_id,
                CampaignInfo.name
            ).all()
            
            # 更新 campaign_info 表
            updated_campaigns = []
            for row in summary:
                spend = float(row.total_spend or 0)
                installs = int(row.total_installs or 0)
                clicks = int(row.total_clicks or 0)
                impressions = int(row.total_impressions or 0)
                purchases = int(row.total_purchases or 0)

                campaign = db.session.get(CampaignInfo, row.id)
                if campaign:
                    campaign.total_spend = spend
                    campaign.total_installs = installs
                    campaign.total_clicks = clicks
                    campaign.total_impressions = impressions
                    campaign.total_purchases = purchases
                    campaign.start_date = row.start_date
                    campaign.end_date = row.end_date
                    campaign.cpm = calculate_rate(spend, impressions, 1000)
                    campaign.cpc = calculate_rate(spend, clicks)
                    campaign.cpi = calculate_rate(spend, installs)
                    campaign.cpa = calculate_rate(spend, purchases)
                    campaign.ctr = calculate_rate(clicks, impressions, 100)
                    campaign.cvr = calculate_rate(installs, clicks, 100)
                    updated_campaigns.append(campaign)

            db.session.commit()
            logger.info(f"Successfully updated campaign stats at {datetime.now()}")
            
            # 检查并关停不达标的广告
            check_and_disable_campaigns(updated_campaigns)
            
    except Exception as e:
        logger.error(f"Error updating summary: {str(e)}")
        with app.app_context():
            db.session.rollback()
        raise

def init_scheduler():
    scheduler = BackgroundScheduler()
    scheduler.add_job(
        update_summary, 
        'interval', 
        minutes=APP_CONFIG['update_interval']
    )
    scheduler.start()
    logger.info("Scheduler started")

if __name__ == '__main__':
    update_summary()