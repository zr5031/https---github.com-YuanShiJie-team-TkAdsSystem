from flask import Flask, render_template, request
from flask_sqlalchemy import SQLAlchemy
from config import DB_CONFIG, APP_CONFIG

app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = (
    f"mysql+pymysql://{DB_CONFIG['user']}:{DB_CONFIG['password']}"
    f"@{DB_CONFIG['host']}/{DB_CONFIG['database']}"
)
db = SQLAlchemy(app)

class CampaignInfo(db.Model):
    __tablename__ = 'campaign_info'
    id = db.Column(db.Integer, primary_key=True)
    tiktok_campaign_id = db.Column(db.String(32))
    name = db.Column(db.String(255))
    total_spend = db.Column(db.Float(6,2), default=0)
    total_installs = db.Column(db.Integer, default=0)
    total_clicks = db.Column(db.Integer, default=0)
    total_impressions = db.Column(db.Integer, default=0)
    total_purchases = db.Column(db.Integer, default=0)
    start_date = db.Column(db.Date)
    end_date = db.Column(db.Date)
    cpi = db.Column(db.Float(6,2), default=0)
    cpm = db.Column(db.Float(6,2), default=0)
    cpc = db.Column(db.Float(6,2), default=0)
    cpa = db.Column(db.Float(6,2), default=0)
    ctr = db.Column(db.Float(6,2), default=0)
    cvr = db.Column(db.Float(6,2), default=0)

@app.route('/')
def index():
    sort_by = request.args.get('sort', 'total_spend')
    order = request.args.get('order', 'desc')
    
    query = CampaignInfo.query
    
    sort_column = getattr(CampaignInfo, sort_by, CampaignInfo.total_spend)
    if order == 'asc':
        query = query.order_by(sort_column.asc())
    else:
        query = query.order_by(sort_column.desc())
    
    campaigns = query.all()
    return render_template('index.html', campaigns=campaigns, current_sort=sort_by, current_order=order)

if __name__ == '__main__':
    app.run(
        debug=APP_CONFIG['debug'], 
        port=APP_CONFIG['port']
    )
